package MustBe::Loaded;
use strict;

our $VERSION = 0.01;

1;
